const menuButton = document.querySelector('[data-menu-toggle]');
const mobileNav = document.querySelector('[data-mobile-nav]');

menuButton?.addEventListener('click', () => {
  mobileNav?.classList.toggle('is-open');
});

mobileNav?.addEventListener('click', (event) => {
  if (event.target instanceof HTMLAnchorElement) {
    mobileNav.classList.remove('is-open');
  }
});

const yandexMetrikaId = document
  .querySelector('meta[name="yandex-metrika-id"]')
  ?.getAttribute('content')
  ?.trim();

if (yandexMetrikaId && /^\d+$/.test(yandexMetrikaId)) {
  window.ym =
    window.ym ||
    function () {
      (window.ym.a = window.ym.a || []).push(arguments);
    };
  window.ym.l = Number(new Date());

  const metrikaScript = document.createElement('script');
  metrikaScript.async = true;
  metrikaScript.src = 'https://mc.yandex.ru/metrika/tag.js';
  document.head.appendChild(metrikaScript);

  window.ym(Number(yandexMetrikaId), 'init', {
    accurateTrackBounce: true,
    clickmap: true,
    trackLinks: true,
    webvisor: true,
  });

  document.querySelectorAll('[data-ym-goal]').forEach((link) => {
    link.addEventListener('click', () => {
      window.ym(Number(yandexMetrikaId), 'reachGoal', link.dataset.ymGoal);
    });
  });
}
