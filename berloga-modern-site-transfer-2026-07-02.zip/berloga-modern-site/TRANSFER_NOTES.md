# Berloga Modern Site - transfer notes

## What is inside

This folder contains the static website for the cigar club "Berloga":

- `index.html` - main page
- `styles.css` - visual styles
- `script.js` - menu behavior and prepared Yandex.Metrika goal tracking
- `assets/images/` - local image assets
- `robots.txt` and `sitemap.xml` - search indexing files
- `vercel.json` and `CNAME` - Vercel/domain deployment files
- `README.md` and `DEPLOY.md` - project notes

## Current production domain

Main domain:

```text
https://berloga-ekb.ru/
```

The `www` version was configured in Vercel as a 301 redirect to the main domain:

```text
https://www.berloga-ekb.ru/ -> https://berloga-ekb.ru/
```

## DNS records that were configured in REG.RU

```text
A      @     216.198.79.1
CNAME  www   e7d1b7f81bd1b7b1.vercel-dns-017.com.
```

## Vercel project

The site was initially published through Vercel Drop to Deploy as:

```text
berloga-modern-site
```

Production URL:

```text
https://berloga-modern-site.vercel.app/
```

Because it was uploaded manually through Vercel, future updates require either:

- re-uploading this folder through Vercel Drop to Deploy, or
- connecting the project to a GitHub repository for normal deployments.

## Yandex setup status

Prepared locally:

- local business structured data for search engines
- `robots.txt`
- `sitemap.xml`
- canonical URL
- Open Graph image
- prepared Yandex.Metrika goal names:
  - `phone_click`
  - `booking_click`
  - `tasting_click`

Still needed:

1. Create or open a Yandex.Metrika counter for `berloga-ekb.ru`.
2. Put the numeric counter ID into this tag in `index.html`:

```html
<meta name="yandex-metrika-id" content="">
```

Example:

```html
<meta name="yandex-metrika-id" content="12345678">
```

3. If Yandex.Webmaster gives a verification tag, add it inside `<head>` in `index.html`.
4. Publish the updated folder to Vercel.
5. Add `https://berloga-ekb.ru/sitemap.xml` in Yandex.Webmaster.

## Local preview

From this folder, run:

```bash
python3 -m http.server 4177
```

Then open:

```text
http://localhost:4177/
```
